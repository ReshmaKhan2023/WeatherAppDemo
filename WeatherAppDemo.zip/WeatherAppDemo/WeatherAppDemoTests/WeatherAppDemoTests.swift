//
//  WeatherAppDemoTests.swift
//  WeatherAppDemoTests
//
//  Created by Tork Software on 16/10/24.
//

import XCTest
import Combine
@testable import WeatherAppDemo


//struct WeatherAppDemoTests {

//    @Test func example() async throws {
//        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
//    }

//}

final class WeatherAppDemoTests: XCTestCase {
    var viewModel: WeatherViewModel!
    var cancellables: Set<AnyCancellable>!
    
    override func setUpWithError() throws {
        viewModel = WeatherViewModel()
        cancellables = []
    }
    
    override func tearDownWithError() throws {
        viewModel = nil
        cancellables = nil
    }
    
    func testFetchWeatherSucess() throws {
        //set up mock data
        let jsonString = """
        {
            
"weather": [{
      "id": 803,
      "main": "Clouds",
      "description": "broken clouds",
      "icon": "04d"
    }],
"main": {
    "temp": 47.07,
    "feels_like": 44.31,
    "temp_min": 43.88,
    "temp_max": 48.72,
    "pressure": 1018,
    "humidity": 74,
    "sea_level": 1018,
    "grnd_level": 984
  },
 "name": "Atlanta",
}
"""
        MockUrlProtocol.testData = jsonString.data(using: .utf8)
        
        let config = URLSessionConfiguration.default
        config.protocolClasses = [MockUrlProtocol.self]
        let session = URLSession(configuration: config)
        
        viewModel.session = session
        
        let expectation  = self.expectation(description: "Fetching Weather")
        viewModel.$weather.sink { weather in
            if let weather = weather {
                XCTAssertEqual(weather.name, "Atlanta")
                XCTAssertEqual(weather.main.temp, 80.00)
                XCTAssertEqual(weather.weather.first?.description, "Clear Sky")
                expectation.fulfill()
            }
            
        }
        .store(in: &cancellables)
        viewModel.fetchWeather(for: "Atlanta")
        waitForExpectations(timeout: 5, handler: nil)
    }
    
    func testFetchWeatherFailure() throws {
        MockUrlProtocol.testData = nil
        
        let config = URLSessionConfiguration.default
        config.protocolClasses = [MockUrlProtocol.self]
        let session = URLSession(configuration: config)
        
        viewModel.session = session
        let expectation  = self.expectation(description: "Fetching Weather Failed")
        
        viewModel.$errorMessage
            .sink { errorMessage in
                if let errorMessage = errorMessage {
                    XCTAssertEqual(errorMessage, "Invalid Data")
                    expectation.fulfill()
                }
            }
            .store(in: &cancellables)
        viewModel.fetchWeather(for: "Atlanta")
        waitForExpectations(timeout: 5, handler: nil)
    }
}
    
    
    
class MockUrlProtocol: URLProtocol {
    static var testData: Data?
    
    override class func canInit(with request: URLRequest) -> Bool {
        return true
    }
    
    override class func canonicalRequest(for request: URLRequest) -> URLRequest {
        return request
    }
    override func startLoading() {
        if let data = MockUrlProtocol.testData {
            self.client?.urlProtocol(self, didLoad: data)
        }
        self.client?.urlProtocolDidFinishLoading(self)
    }
    override func stopLoading() {
        
    }
}
