//
//  Weather.swift
//  WeatherAppDemo
//
//  Created by Tork Software on 15/10/24.
//

import Foundation

struct Weather: Decodable {
    let main : Main
    let weather : [WeatherElement]
    let name : String
    
    
    struct Main: Decodable {
        let temp : Double
        let humidity : Double
    }
    
    struct WeatherElement: Decodable {
        let description : String
        let icon : String
    }
}
