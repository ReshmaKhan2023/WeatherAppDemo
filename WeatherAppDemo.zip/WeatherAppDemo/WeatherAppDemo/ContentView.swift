//
//  ContentView.swift
//  WeatherAppDemo
//
//  Created by Tork Software on 15/10/24.
//

import SwiftUI

struct ContentView: View {
    
    @StateObject private var viewModel = WeatherViewModel()
    @State private var city: String = "London"
    
    var body: some View {
        NavigationView {
            VStack {
                TextField("Please Enter City Name", text: $city)
                    .textFieldStyle(.roundedBorder).padding()
                
                if viewModel.isLoading {
                    ProgressView()
                } else if let weather = viewModel.weather {
                    VStack {
                        Text(weather.name)
                            .font(.largeTitle)
                            .padding()
                        
                        Text("\(weather.main.temp, specifier: "%.1f")F")
                        
                        Text(weather.weather.first?.description.capitalized ?? "")
                            .font(.title2)
                            .padding()
                        
                        HStack {
                            Text("Humidity: \(weather.main.humidity, specifier: "%.0f")%")
                            Spacer()
                            AsyncImage(url: URL(string: "https://openweathermap.org/img/wn/\(weather.weather.first?.icon ?? "01d")@2x.png"))
                        }
                        .padding()
                    }
                } else if let errorMessage = viewModel.errorMessage {
                    
                    Text(errorMessage)
                        .foregroundColor(.blue)
                        .padding()
                }
                Spacer()
                Button(action: {
                    viewModel.fetchWeather(for: city)
                }) {
                    Text("Get Weather")
                        .padding()
                        .background(Color.gray)
                        .foregroundColor(.white)
                        .cornerRadius(8)
                }
                .padding()
            }
            .navigationTitle("Weather App")
        }
    }
}

#Preview {
    ContentView()
}
