//
//  WeatherAppDemoApp.swift
//  WeatherAppDemo
//
//  Created by Tork Software on 15/10/24.
//

import SwiftUI

@main
struct WeatherAppDemoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
