//
//  WeatherViewModel.swift
//  WeatherAppDemo
//
//  Created by Tork Software on 15/10/24.
//

import Foundation
import Combine

class WeatherViewModel: ObservableObject {
    @Published var weather : Weather?
    @Published var errorMessage : String?
    @Published var isLoading = false
    
    private var cancellable = Set<AnyCancellable>()
    var session: URLSession
    
    init(session: URLSession = .shared) {
        self.session = session
    }
    
    func fetchWeather(for city: String) {
        guard let url = URL(string: "https://api.openweathermap.org/data/2.5/weather?q=\(city)&appid=b8a3771b6ff08ed9368b0e21fa301b7b&units=imperial")
        else {
            errorMessage = "Invalid City URL"
            return
        }
        
        isLoading = true
        errorMessage = nil
        
        session.dataTaskPublisher(for: url)
            .map{ $0.data }
            .decode(type: Weather.self, decoder: JSONDecoder())
            .receive(on: DispatchQueue.main)
            .sink(receiveCompletion: {
                completion in
                self.isLoading = false
                switch completion {
                case .finished:
                    break
                case .failure(let error):
                    self.errorMessage = error.localizedDescription
                }
            }, receiveValue: { weather  in
                self.weather = weather
            })
            .store(in: &self.cancellable)
        
    }
}
